WooCommerce Healthcare Automation Media Pack
------------------------------------------------
Contents:
- Mockups for all 5 automations + bundle
- WooCommerce CSV product import file
- License document

Import Process:
1. Upload the CSV file under WooCommerce → Products → Import.
2. Add the corresponding mockup image to each product page.
3. Attach the relevant .json automation file as a digital download.

Created by ProtoLabs Global — www.protolabsglobal.com
